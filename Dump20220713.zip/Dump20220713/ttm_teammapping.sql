-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: ttm
-- ------------------------------------------------------
-- Server version	5.6.51-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `teammapping`
--

DROP TABLE IF EXISTS `teammapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teammapping` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `billing_customer_emailid` varchar(255) DEFAULT NULL,
  `billing_head_email` varchar(255) DEFAULT NULL,
  `cs_user_email` varchar(255) DEFAULT NULL,
  `dispatch_team_email` varchar(255) DEFAULT NULL,
  `dispatch_team_head_email` varchar(255) DEFAULT NULL,
  `dsr_emailid` varchar(255) DEFAULT NULL,
  `finance_user_email` varchar(255) DEFAULT NULL,
  `forwarder_name` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `product_head_user_email` varchar(255) DEFAULT NULL,
  `shipment_mode` varchar(255) DEFAULT NULL,
  `shipment_type` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `upload_user_email` varchar(255) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL DEFAULT 'system',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_modified_by` varchar(50) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teammapping`
--

LOCK TABLES `teammapping` WRITE;
/*!40000 ALTER TABLE `teammapping` DISABLE KEYS */;
INSERT INTO `teammapping` VALUES (1,'mayuri.ha@blute.co.in','BillingHead1@localhost.com','csteam1@localhost.com','dispatch1@localost.com','DispatchTeamHead1@localost.com','mayuri.ha@blute.co.in','mayuri.ha@blute.co.in','DHL','Bangalore','producthead1@localhost.com','AIR','IMPORT','ACTIVE','uplteam1@localhost.com','admin','2021-02-17 00:15:41','admin','2021-07-14 01:54:48'),(2,'mayuri.ha@blute.co.in','BillingHead1@localhost.com','csteam1@localhost.com','dispatch1@localost.com','DispatchTeamHead1@localost.com','mayuri.ha@blute.co.in','mayuri.ha@blute.co.in','BLUE DART','Bangalore','producthead1@localhost.com','AIR','EXPORT','ACTIVE','uplteam1@localhost.com','admin','2021-02-17 00:40:45','admin','2021-06-24 00:53:49'),(3,'mayuri.ha@blute.co.in','BillingHead1@localhost.com','csteam1@localhost.com','dispatch1@localost.com','DispatchTeamHead1@localost.com','mayuri.ha@blute.co.in','mayuri.ha@blute.co.in','DHL','Bangalore','producthead1@localhost.com','SEA','IMPORT','ACTIVE','uplteam1@localhost.com','admin','2021-02-18 00:22:09','admin','2021-06-24 00:55:28'),(4,'mayuri.ha@blute.co.in','BillingHead1@localhost.com','csteam1@localhost.com','dispatch1@localost.com','DispatchTeamHead1@localost.com','mayuri.ha@blute.co.in','mayuri.ha@blute.co.in','DHL','Bangalore','producthead1@localhost.com','SEA','EXPORT','ACTIVE','uplteam1@localhost.com','admin','2021-02-18 00:23:26','mayuri','2021-06-21 02:19:39'),(5,'mayuri.ha@blute.co.in','BillingHead1@localhost.com','csteam1@localhost.com','dispatch1@localost.com','DispatchTeamHead1@localost.com','mayuri.ha@blute.co.in','finteam1@localhost.com','DHL','Bangalore','producthead1@localhost.com','LAND_COMPLIANCE','BOND_TO_BOND','ACTIVE','uplteam1@localhost.com','admin','2021-02-18 00:33:11','admin','2021-03-05 05:54:05'),(6,'','BillingHead1@localhost.com','csteam1@localhost.com','dispatch1@localost.com','DispatchTeamHead1@localost.com','','finteam1@localhost.com','DHL','Bangalore','producthead1@localhost.com','LAND_COMPLIANCE','ZONE_TO_ZONE','ACTIVE','uplteam1@localhost.com','admin','2021-02-19 05:07:12','admin','2021-02-22 06:57:45'),(7,'mayuri.ha@blute.co.in','BillingHead1@localhost.com','csteam1@localhost.com','dispatch1@localost.com','DispatchTeamHead1@localost.com','mayuri.ha@blute.co.in','finteam1@localhost.com','AMAZON','Bangalore','producthead1@localhost.com','LAND_COMPLIANCE','ZONE_TO_ZONE','ACTIVE','uplteam1@localhost.com','sushma','2021-03-06 05:33:30','mayuri','2021-05-18 10:51:34'),(8,'jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com','gnnaidu2001@gmail.com','centraldesk2@transorion.com','dispatch1@localost.com','syedwajidsultan@gmail.com','jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com','chnfinance2@transorion.in','Cypress Semiconductors technology India Pvt LtD','Bangalore','vragavan@transorion.com','AIR','IMPORT','ACTIVE','ttmupl1@gmail.com','prashanth','2021-03-09 05:26:08','sushma','2021-06-07 03:13:01'),(9,'srinivasrao@transorion.com;srinivasseelam@transorion.in;hydimports@transorion.com;hydocean@transorion.in','BillingHead1@localhost.com','csteam1@localhost.com','blrdispatch@transorion.in','DispatchTeamHead1@localost.com','srinivasrao@transorion.com;srinivasseelam@transorion.in;hydimports@transorion.com;hydocean@transorion.in','finteam1@localhost.com','DHL','Hyderabad','producthead1@localhost.com','AIR','IMPORT','ACTIVE','uplteam1@localhost.com','sushma','2021-03-17 00:10:24','sushma','2021-06-18 06:05:15'),(10,'srinivasrao@transorion.com;srinivasseelam@transorion.in;hydimports@transorion.com;hydocean@transorion.in','BillingHead1@localhost.com','csteam1@localhost.com','dispatch1@localost.com','DispatchTeamHead1@localost.com','srinivasrao@transorion.com;srinivasseelam@transorion.in;hydimports@transorion.com;hydocean@transorion.in','finteam1@localhost.com','BLUE DART','Hyderabad','producthead1@localhost.com','AIR','EXPORT','ACTIVE','uplteam1@localhost.com','sushma','2021-03-17 00:10:56','sushma','2021-03-17 00:10:56'),(11,'csteam@localhost.com','BillingHead1@localhost.com','csteam1@localhost.com','dispatch1@localost.com','DispatchTeamHead1@localost.com','csteam@localhost.com','finteam1@localhost.com','BLUE DART','Bangalore','producthead1@localhost.com','AIR','IMPORT','ACTIVE','uplteam1@localhost.com','mayuri','2021-04-02 06:39:33','mayuri','2021-04-02 06:39:33'),(12,'guru@transorion.com;prashanthr@transorion.com;jaiganesh@transorion.com;srinivasseelam@transorion.in;srinivasrao@transorion.com;jaffer@transorion.in;sushma@transorion.com;hydair@transorion.in;hydcs1@transorion.in;hydcs@transorion.in;ramesh@transorion.in','gnnaidu2001@gmail.com','hydair@transorion.in','blrdispatch@transorion.in','syedwajidsultan@gmail.com','guru@transorion.com;prashanthr@transorion.com;jaiganesh@transorion.com;srinivasseelam@transorion.in;srinivasrao@transorion.com;jaffer@transorion.in;sushma@transorion.com;hydair@transorion.in;hydcs1@transorion.in;hydcs@transorion.in;ramesh@transorion.in','accounts3@transorion.com','SCHNEIDER ELECTRIC INDIA PVT LTD','Hyderabad','vragavan@transorion.com','SEA','EXPORT','ACTIVE','ttmupl1@gmail.com','prashanth','2021-05-29 10:15:41','sushma','2022-03-19 04:27:54'),(13,'jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com;broadcast1@transorion.in','gnnaidu2001@gmail.com','broadcast1@transorion.in','blrdispatch@transorion.in','syedwajidsultan@gmail.com','jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com;broadcast1@transorion.in','accounts2@transorion.com','SCHNEIDER ELECTRIC IT BUSINESS INDIA PVT LTD','Bangalore','manimaran@transorion.com','SEA','IMPORT','ACTIVE','ttmupl1@gmail.com','sushma','2021-06-07 03:30:02','sushma','2021-06-18 06:05:31'),(14,'jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com;prashanthr@transorion.com;hydcs@transorion.in;ramesh@transorion.in','gnnaidu2001@gmail.com','hydair@transorion.in','blrdispatch@transorion.in','syedwajidsultan@gmail.com','jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com;prashanthr@transorion.com;hydcs@transorion.in;ramesh@transorion.in','accounts3@transorion.com','SCHNEIDER ELECTRIC INDIA PVT LTD','Hyderabad','vragavan@transorion.com','AIR','EXPORT','ACTIVE','ttmupl1@gmail.com','sushma','2021-06-07 03:35:01','sushma','2022-03-19 04:28:35'),(15,'jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com;prashanthr@transorion.com','gnnaidu2001@gmail.com','hydair@transorion.in','blrdispatch@transorion.in','syedwajidsultan@gmail.com','jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com;prashanthr@transorion.com','accounts3@transorion.com','DHL','Hyderabad','vragavan@transorion.com','SEA','EXPORT','ACTIVE','ttmupl1@gmail.com','sushma','2021-06-14 23:34:13','sushma','2021-06-28 07:46:48'),(16,'jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com;prashanthr@transorion.com;centraldesk3@transorion.com;prashanthr@transorion.com','gnnaidu2001@gmail.com','centraldesk3@transorion.com','blrdispatch@transorion.in','syedwajidsultan@gmail.com','jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com;prashanthr@transorion.com;centraldesk3@transorion.com;prashanthr@transorion.com','accounts2@transorion.com','SCHNEIDER ELECTRIC IT BUSINESS INDIA PVT LTD','Bangalore','vragavan@transorion.com','AIR','EXPORT','ACTIVE','ttmupl1@gmail.com','sushma','2021-06-15 06:16:01','sushma','2021-06-28 07:45:53'),(17,'jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com;ravikumar@transorion.com;prashanthr@transorion.com','gnnaidu2001@gmail.com','ravikumar@transorion.com','blrdispatch@transorion.in','syedwajidsultan@gmail.com','jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com;ravikumar@transorion.com;prashanthr@transorion.com','accounts4@transorion.in','SCHNEIDER ELECTRIC IT BUSINESS INDIA PVT LTD','Bangalore','manimaran@transorion.com','SEA','EXPORT','ACTIVE','ttmupl1@gmail.com','sushma','2021-06-15 06:22:27','sushma','2021-06-28 07:44:55'),(18,'jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com;prashanthr@transorion.com;blrairimports@transorion.in;prashanthr@transorion.com','gnnaidu2001@gmail.com','blrairimports@transorion.in','blrdispatch@transorion.in','syedwajidsultan@gmail.com','jaiganesh@transorion.com;sushma@transorion.com;vragavan@transorion.com;manimaran@transorion.com;syedwajid@transorion.com;guru@transorion.com;prashanthr@transorion.com;blrairimports@transorion.in;prashanthr@transorion.com','accounts4@transorion.in','SCHNEIDER ELECTRIC IT BUSINESS INDIA PVT LTD','Bangalore','vragavan@transorion.com','AIR','IMPORT','ACTIVE','ttmupl1@gmail.com','sushma','2021-06-15 22:38:21','sushma','2021-06-28 07:44:29'),(19,'mayuri.ha@blute.co.in','BillingHead1@localhost.com','csteam1@localhost.com','dispatch1@localost.com','DispatchTeamHead1@localost.com','mayuri.ha@blute.co.in','mayuri.ha@blute.co.in','BLUTE TEAMS','Bangalore','producthead1@localhost.com','AIR','IMPORT','ACTIVE','uplteam1@localhost.com','admin','2021-07-13 02:27:28','admin','2021-07-13 02:27:28'),(20,'localhost@co.com','BillingHead2@localhost.com','csteam2@localhost.com','dispatch2@localost.com','DispatchTeamHead2@localost.com','local@local.com','mayuri.ha@blute.co.in','BLUTE TEAMS','Bangalore','producthead2@localhost.com','AIR','IMPORT','ACTIVE','uplteam2@localhost.com','admin','2021-07-15 04:22:06','admin','2021-07-15 04:22:06');
/*!40000 ALTER TABLE `teammapping` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-13 22:14:02
