-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: ttm
-- ------------------------------------------------------
-- Server version	5.6.51-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `jhi_persistent_audit_evt_data`
--

DROP TABLE IF EXISTS `jhi_persistent_audit_evt_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jhi_persistent_audit_evt_data` (
  `event_id` bigint(20) NOT NULL,
  `name` varchar(150) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`event_id`,`name`),
  KEY `idx_persistent_audit_evt_data` (`event_id`),
  CONSTRAINT `fk_evt_pers_audit_evt_data` FOREIGN KEY (`event_id`) REFERENCES `jhi_persistent_audit_event` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jhi_persistent_audit_evt_data`
--

LOCK TABLES `jhi_persistent_audit_evt_data` WRITE;
/*!40000 ALTER TABLE `jhi_persistent_audit_evt_data` DISABLE KEYS */;
INSERT INTO `jhi_persistent_audit_evt_data` VALUES (22804,'message','Bad credentials'),(22804,'type','org.springframework.security.authentication.BadCredentialsException'),(22805,'message','Bad credentials'),(22805,'type','org.springframework.security.authentication.BadCredentialsException'),(22806,'message','Bad credentials'),(22806,'type','org.springframework.security.authentication.BadCredentialsException'),(22807,'message','Bad credentials'),(22807,'type','org.springframework.security.authentication.BadCredentialsException'),(22808,'message','Bad credentials'),(22808,'type','org.springframework.security.authentication.BadCredentialsException'),(22809,'message','Bad credentials'),(22809,'type','org.springframework.security.authentication.BadCredentialsException'),(22947,'message','Bad credentials'),(22947,'type','org.springframework.security.authentication.BadCredentialsException'),(22975,'message','Bad credentials'),(22975,'type','org.springframework.security.authentication.BadCredentialsException'),(22977,'message','Bad credentials'),(22977,'type','org.springframework.security.authentication.BadCredentialsException'),(22978,'message','Bad credentials'),(22978,'type','org.springframework.security.authentication.BadCredentialsException'),(22985,'message','Bad credentials'),(22985,'type','org.springframework.security.authentication.BadCredentialsException'),(22986,'message','Bad credentials'),(22986,'type','org.springframework.security.authentication.BadCredentialsException'),(22988,'message','Bad credentials'),(22988,'type','org.springframework.security.authentication.BadCredentialsException'),(22989,'message','Bad credentials'),(22989,'type','org.springframework.security.authentication.BadCredentialsException'),(22990,'message','Bad credentials'),(22990,'type','org.springframework.security.authentication.BadCredentialsException'),(22991,'message','Bad credentials'),(22991,'type','org.springframework.security.authentication.BadCredentialsException'),(23001,'message','Bad credentials'),(23001,'type','org.springframework.security.authentication.BadCredentialsException'),(23006,'message','Bad credentials'),(23006,'type','org.springframework.security.authentication.BadCredentialsException'),(23007,'message','Bad credentials'),(23007,'type','org.springframework.security.authentication.BadCredentialsException'),(23027,'message','Bad credentials'),(23027,'type','org.springframework.security.authentication.BadCredentialsException'),(23028,'message','Bad credentials'),(23028,'type','org.springframework.security.authentication.BadCredentialsException'),(23029,'message','Bad credentials'),(23029,'type','org.springframework.security.authentication.BadCredentialsException'),(23030,'message','Bad credentials'),(23030,'type','org.springframework.security.authentication.BadCredentialsException'),(23111,'message','Bad credentials'),(23111,'type','org.springframework.security.authentication.BadCredentialsException'),(23112,'message','Bad credentials'),(23112,'type','org.springframework.security.authentication.BadCredentialsException'),(23113,'message','Bad credentials'),(23113,'type','org.springframework.security.authentication.BadCredentialsException'),(23114,'message','Bad credentials'),(23114,'type','org.springframework.security.authentication.BadCredentialsException'),(23122,'message','Bad credentials'),(23122,'type','org.springframework.security.authentication.BadCredentialsException'),(23123,'message','Bad credentials'),(23123,'type','org.springframework.security.authentication.BadCredentialsException'),(23124,'message','Bad credentials'),(23124,'type','org.springframework.security.authentication.BadCredentialsException'),(23125,'message','Bad credentials'),(23125,'type','org.springframework.security.authentication.BadCredentialsException'),(23126,'message','Bad credentials'),(23126,'type','org.springframework.security.authentication.BadCredentialsException'),(23127,'message','Bad credentials'),(23127,'type','org.springframework.security.authentication.BadCredentialsException'),(23128,'message','Bad credentials'),(23128,'type','org.springframework.security.authentication.BadCredentialsException'),(23129,'message','Bad credentials'),(23129,'type','org.springframework.security.authentication.BadCredentialsException'),(23130,'message','Bad credentials'),(23130,'type','org.springframework.security.authentication.BadCredentialsException'),(23131,'message','Bad credentials'),(23131,'type','org.springframework.security.authentication.BadCredentialsException'),(23132,'message','Bad credentials'),(23132,'type','org.springframework.security.authentication.BadCredentialsException'),(23133,'message','Bad credentials'),(23133,'type','org.springframework.security.authentication.BadCredentialsException'),(23134,'message','Bad credentials'),(23134,'type','org.springframework.security.authentication.BadCredentialsException'),(23135,'message','Bad credentials'),(23135,'type','org.springframework.security.authentication.BadCredentialsException'),(23136,'message','Bad credentials'),(23136,'type','org.springframework.security.authentication.BadCredentialsException'),(23137,'message','Bad credentials'),(23137,'type','org.springframework.security.authentication.BadCredentialsException'),(23183,'message','Bad credentials'),(23183,'type','org.springframework.security.authentication.BadCredentialsException'),(23188,'message','Bad credentials'),(23188,'type','org.springframework.security.authentication.BadCredentialsException'),(23189,'message','Bad credentials'),(23189,'type','org.springframework.security.authentication.BadCredentialsException'),(23190,'message','Bad credentials'),(23190,'type','org.springframework.security.authentication.BadCredentialsException'),(23191,'message','Bad credentials'),(23191,'type','org.springframework.security.authentication.BadCredentialsException'),(23192,'message','Bad credentials'),(23192,'type','org.springframework.security.authentication.BadCredentialsException'),(23193,'message','Bad credentials'),(23193,'type','org.springframework.security.authentication.BadCredentialsException'),(23194,'message','Bad credentials'),(23194,'type','org.springframework.security.authentication.BadCredentialsException'),(23346,'message','Bad credentials'),(23346,'type','org.springframework.security.authentication.BadCredentialsException'),(23356,'message','Bad credentials'),(23356,'type','org.springframework.security.authentication.BadCredentialsException'),(23358,'message','Bad credentials'),(23358,'type','org.springframework.security.authentication.BadCredentialsException');
/*!40000 ALTER TABLE `jhi_persistent_audit_evt_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-13 22:14:21
